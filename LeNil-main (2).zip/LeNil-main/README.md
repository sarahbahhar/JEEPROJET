# DevWebIng1
Projet Dev Web d'Ing1 GI


Pour lancer notre projet, il faut avoir un serveur MYSQL et un serveur local PHP (Installer XAMPP est une solution pour avoir les 2).

IL faut acceder à la base de donnée via phpmyadmin (en mettant localhost/phpMyAdmin dans la base de recherche).
Suite à cela, un identifiant et un mot de passe vont etre demandé. L'identifiant est 'root' et le mot de passe est 'cytech0001'.

On peut maintenant se connecter à l'index (localhost/Chemin).

Vous pouvez maintenant naviguez dans LENIL comme bon vous semble.

Lien du git du projet :
https://github.com/Hanabi-TheFox/LeNil 
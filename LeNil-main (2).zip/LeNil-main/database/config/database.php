<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'cytech0001');
define('DB_NAME', 'lenil');

$dbServerName = "localhost";
$dbUserName="root";
$dbName = "lenil";

//CLIENT//////////////
//Une fois le client connectée, il aura accés à son compte
//et au panier
?>
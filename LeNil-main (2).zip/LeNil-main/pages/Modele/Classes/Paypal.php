<?
class Paypal extends MoyenPayment {

    private $Paypal;

    function __construct($Paypall) { 
        $this -> $this->CodePromo;
        
      }
    function getPaypal() {
        return $this->Paypal;
    }
}

?>
<?
class CB extends MoyenPayment {
    private $CB;

    function __construct($CB) { 
        $this -> $this->CB;
        
      }

      function getPaypal() {
        return $this->CB;
    }
}
<link rel="stylesheet" href="../../css/footer.css">  
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

<footer class="footer">
    <div class="p1">
        <div class="c1">
            <h5 class="color pt2">Trouvez-nous</h5>
            <p><i class="fa fa-location-arrow"></i> 57 rue du moine 95000 Cergy </p>
            <p><i class="fa fa-phone"></i>  07-00-00-00-00  </p>
            <p><i class="fa fa fa-envelope"></i> websiteprojet2023@gmail.com  </p>
        </div>

        <div class="c1">
            <h5 class="color pt2">Concepteurs</h5>
            <ul class="name">
                <li>Ethan PINTO</li>
                <li>Clément FOULON</li>
                <li>Abdellah HASSANI</li>
                <li>Samy BELBOUAB</li>
                <li>Renato Daniel NASCIMENTO ARDILES</li>
            </ul>
        </div>
    </div>
    <div class="line"></div>
    <div>
        <ul class="button_link">
            <li><a href=profil.php>Profil</a></li>
            <li><a href=index.php>Accueil</a></li>
            <li><a href=about.php>A propos</a></li>
            <li><a href=contact.php>Contacter</a></li>
        </ul>
        <center>© 2023, LeNil.com</center>
            <ul class="logo">
                <li style="padding-left: 0px;"><a><i class="fab fa-facebook-f"></i></a></li>
                <li><a><i class="fab fa-twitter"></i></a></li>
                <li><a><i class="fab fa-linkedin"></i></a></li>
                <li><a><i class="fab fa-instagram"></i></a></li>
            </ul>
            
    </div>
</footer>
